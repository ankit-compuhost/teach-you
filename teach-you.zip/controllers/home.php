<?php
include("models/" . $page . "-models.php");
?>