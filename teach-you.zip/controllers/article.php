<?php
include("models/" . $page . "-models.php");
$allArticle = getAllArticle();
?>