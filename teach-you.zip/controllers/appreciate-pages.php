<?php
include("models/" . $page . "-models.php");
$allPages = getAllPages();

//Create
include ("common/create-pages.php");

?>