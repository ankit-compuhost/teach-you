tinymce.init({
        selector: '#mytextarea'
      });