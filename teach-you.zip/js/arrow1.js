(function(document){
  var div = document.getElementById('headingOne');
  var icon = document.getElementById('icon');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);



(function(document){
  var div = document.getElementById('headingTwo');
  var icon = document.getElementById('icon2');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);


(function(document){
  var div = document.getElementById('headingThree');
  var icon = document.getElementById('icon3');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);



(function(document){
  var div = document.getElementById('headingFour');
  var icon = document.getElementById('icon4');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);



(function(document){
  var div = document.getElementById('headingFive');
  var icon = document.getElementById('icon5');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);



(function(document){
  var div = document.getElementById('headingSix');
  var icon = document.getElementById('icon6');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);



(function(document){
  var div = document.getElementById('headingSix');
  var icon = document.getElementById('icon6');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);



(function(document){
  var div = document.getElementById('headingSeven');
  var icon = document.getElementById('icon7');
  var open = false;

  div.addEventListener('click', function(){
    if(open){
      icon.className = 'fa fa-angle-down';  
    } else{
      icon.className = 'fa fa-angle-down open';
    }

    open = !open;
  });
})
          (document);