Morris.Donut({
  element: 'donut-example',
  data: [
    {label: "Banned Users", value: 12},
    {label: "Active Users", value: 30},
    {label: "Inactive users", value: 20}
  ]
});