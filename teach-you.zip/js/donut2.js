Morris.Donut({
  element: 'donut-example2',
  data: [
    {label: "Male Users", value: 120},
    {label: "Female Users", value: 100},
    {label: "Other Users", value: 37}
  ]
});