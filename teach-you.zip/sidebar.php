 <nav class="nav flex-column">
  <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="#">
     <img src="https://compuhost.co.in/teachyou/images/sidenav/admin.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-admin-text">Admin Panel</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="#">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/home.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-home-text">Home</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="article.php">
     <img src="https://compuhost.co.in/teachyou/images/sidenav/book.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-articles-text">Articles</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="events.php">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/calendar.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-events-text">Events</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="topics.php">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/tag.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-topics-text">Topics</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="friends-youmayknow.php">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/friend.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-friends-text">Friends</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="pages.php">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/page.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-pages-text">Pages</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="groups.php">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/groupicon.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-groups-text">Groups</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="#">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/chat.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-chat-text">Chat</span></a>
      
      <a class="ThisClass nav-link active sidebar-text sidebar-custom " aria-current="page" href="#">
      <img src="https://compuhost.co.in/teachyou/images/sidenav/game.png" style="height:30px; width:30px;">&nbsp;&nbsp;<span id="sidebar-games-text">Quizzes and Games</span></a>
    
  
</nav>