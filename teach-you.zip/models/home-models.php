<?php
include("db.php");

?>